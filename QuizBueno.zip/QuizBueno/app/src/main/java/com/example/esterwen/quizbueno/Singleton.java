package com.example.esterwen.quizbueno;

import java.util.ArrayList;

/**
 * Created by Esterwen on 13/12/17.
 */

public class Singleton {
    private static Singleton mInstance = null;
    private Integer nAciertos;
    private Integer nFallos;
    private ArrayList<String> questions = new ArrayList<String>();
    private ArrayList<String> answer1 = new ArrayList<String>();
    private ArrayList<String> answer2 = new ArrayList<String>();
    private ArrayList<String> answer3 = new ArrayList<String>();

    private ArrayList<String> correctAnswers = new ArrayList<String>();
    public Singleton(){
        questions.add("Cuántas islas componen Canarias?");
        correctAnswers.add("7");
        answer1.add("7");
        answer2.add("5");
        answer3.add("6");

        questions.add("Cuándo se instaló el primer semáforo?");
        correctAnswers.add("1868");
        answer1.add("1769");
        answer2.add("1868");
        answer3.add("1880");

        questions.add("Cuánto mide el Teide?");
        correctAnswers.add("3718 metros");
        answer1.add("2819 metros");
        answer2.add("3656 metros");
        answer3.add("3718 metros");

        questions.add("En un PIC18F4321, cuántos ciclos tarda en ejecutarse la instrucción BTFSS?");
        correctAnswers.add("1,2 o 3");
        answer1.add("2");
        answer2.add("1");
        answer3.add("1,2 o 3");

        questions.add("En un PIC18F4321, cuál es la frecuencia máxima de oscilación?");
        correctAnswers.add("40Mhz");
        answer1.add("40Mhz");
        answer2.add("1GHz");
        answer3.add("15Mhz");

        questions.add("En un PIC18F4321, para qué sirve el PLL?");
        correctAnswers.add("Multiplica la frecuencia por 4");
        answer1.add("Multiplica la frecuencia por 2");
        answer2.add("Multiplica la frecuencia por 4");
        answer3.add("Divide la frecuencia por 6");

        questions.add("Cuál no es un estado de un transistor?");
        correctAnswers.add("Superpositrón");
        answer1.add("Saturación");
        answer2.add("Corte");
        answer3.add("Superpositrón");

        questions.add("Cuáles es el nombre real de Lady Gaga?");
        correctAnswers.add("Stefani Joanne Angelina Germanotta");
        answer1.add("Stefani Marie Angelina Gorgmannotta");
        answer2.add("Stefani Joanne Angelina Germanotta");
        answer3.add("Marie Angelina Hoffman");

        questions.add("Cuál es el sexto decimal de pi?");
        correctAnswers.add("2");
        answer1.add("5");
        answer2.add("9");
        answer3.add("2");

    }

    public static Singleton getInstance(){
        if(mInstance == null){
            mInstance = new Singleton();
        }
        return mInstance;
    }
    public void clearNums(){
        this.nAciertos = 0;
        this.nFallos = 0;
    }

    public static Singleton getmInstance() {
        return mInstance;
    }

    public String getCorrectAnswers(int i) {

        return correctAnswers.get(i);
    }

    public void setCorrectAnswers(ArrayList<String> correctAnswers) {
        this.correctAnswers = correctAnswers;
    }

    public String getQuestion(int i) {

        return questions.get(i);
    }
    public Integer getQuestionsSize() {

        return questions.size();
    }


    public void setQuestions(ArrayList<String> questions) {
        this.questions = questions;
    }

    public Integer getnFallos() {

        return nFallos;
    }

    public void setnFallos() {

        this.nFallos = nFallos+1;
    }

    public Integer getnAciertos() {

        return nAciertos;
    }

    public void setnAciertos() {
        this.nAciertos = nAciertos+1;
    }

    public String getAnswer1(int i) {
        return answer1.get(i);
    }

    public void setAnswer1(ArrayList<String> answer1) {
        this.answer1 = answer1;
    }

    public String getAnswer2(int i) {
        return answer2.get(i);
    }

    public void setAnswer2(ArrayList<String> answer2) {
        this.answer2 = answer2;
    }

    public String getAnswer3(int i) {
        return answer3.get(i);
    }
    public void setAnswer3(ArrayList<String> answer3) {
        this.answer2 = answer3;
    }
}
