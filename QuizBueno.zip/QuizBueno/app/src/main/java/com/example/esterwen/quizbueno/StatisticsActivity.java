package com.example.esterwen.quizbueno;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Esterwen on 18/12/17.
 */

public class StatisticsActivity extends AppCompatActivity {
    private TextView tvA;
    private TextView tvF;
    private TextView tvN,tvG,tvP;
    private ImageView img;
    private double percent = 0;


    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);
        tvA =  (TextView) findViewById(R.id.AciertosNumero);
        tvF =  (TextView) findViewById(R.id.FallosNumero);
        tvN = (TextView) findViewById(R.id.PregNumero);
        tvG = (TextView) findViewById(R.id.Greeting);
        tvP = (TextView) findViewById(R.id.percent);
        img = (ImageView) findViewById(R.id.pic);

        tvA.setText(Singleton.getInstance().getnAciertos().toString());
        tvF.setText(Singleton.getInstance().getnFallos().toString());
        tvN.setText(Singleton.getInstance().getQuestionsSize().toString());
        percent = (double)(Singleton.getInstance().getnAciertos()) / Singleton.getInstance().getQuestionsSize();
        Log.e("adsfsdf",String.valueOf(percent));
        tvP.setText(String.valueOf(Math.round(percent*100)));
        if (percent >= 0.7) {
            tvG.setText("Bien hecho! Felicidades!");
            img.setImageResource(R.mipmap.happy);

        }else if (percent >= 0.5){
            tvG.setText("A la próxima seguro que te sale mejor!");
            img.setImageResource(R.mipmap.normal);
        } else{
            tvG.setText("Deberías estudiar más!");
            img.setImageResource(R.mipmap.sad);
        }

    }
}
