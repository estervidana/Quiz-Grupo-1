package com.example.esterwen.quizbueno;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import com.example.esterwen.quizbueno.R;

/**
 * Created by Esterwen on 13/12/17.
 */

public class QuizActivity extends AppCompatActivity{
    private RadioGroup rg;
    private TextView textView,tvX,tvY;
    private Button boton;
    private int index = '0';
    private Integer numRespuesta = 0;
    private RadioButton rb1;
    private RadioButton rb2;
    private RadioButton rb3;




    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quizlinear);

        rg = (RadioGroup) findViewById(R.id.radiogrup);
        textView = (TextView) findViewById(R.id.textView);
        tvX = (TextView) findViewById(R.id.tvX);
        tvY = (TextView) findViewById(R.id.tvY);

        boton = (Button) findViewById(R.id.buttonQuiz);
        rb1 = (RadioButton) findViewById(R.id.radioButton);
        rb2 = (RadioButton) findViewById(R.id.radioButton2);
        rb3 = (RadioButton) findViewById(R.id.radioButton3);

        rb1.setText(Singleton.getInstance().getAnswer1(0));
        rb2.setText(Singleton.getInstance().getAnswer2(0));
        rb3.setText(Singleton.getInstance().getAnswer3(0));
        textView.setText(Singleton.getInstance().getQuestion(0));
        Singleton.getInstance().clearNums();
        tvX.setText("1");
        tvY.setText(Singleton.getInstance().getQuestionsSize().toString());

        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup rg, int i) {
                Log.d("QuizActivity", "i " +i);
                switch(i) {
                    case R.id.radioButton:
                        Log.e("QuizActivity", "RB 1 has been pressed ");
                        index = 1;
                        break;
                    case R.id.radioButton2:
                        Log.e("QuizActivity", "RB 2 has been pressed ");
                        index = 2;
                        break;
                    case R.id.radioButton3:
                        Log.e("QuizActivity", "RB 3 has been pressed ");
                        index = 3;
                        break;

                }
            }

        });
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rb1.setChecked(false);
                rb2.setChecked(false);
                rb3.setChecked(false);

                switch(index){
                    case 0:
                        break;
                    case 1:
                        if (Singleton.getInstance().getAnswer1(numRespuesta).equals(Singleton.getInstance().getCorrectAnswers(numRespuesta))){
                            //Es correcta, sumamos un acierto
                            Singleton.getInstance().setnAciertos();
                            Log.e("QuizActivity", "Acierto ");
                        }else{
                            Singleton.getInstance().setnFallos();
                        }
                        break;
                    case 2:
                        if (Singleton.getInstance().getAnswer2(numRespuesta).equals(Singleton.getInstance().getCorrectAnswers(numRespuesta))){
                            //Es correcta, sumamos un acierto
                            Singleton.getInstance().setnAciertos();
                            Log.e("QuizActivity", "Acierto ");

                        }else{
                            Singleton.getInstance().setnFallos();
                        }
                        break;
                    case 3:
                        if (Singleton.getInstance().getAnswer3(numRespuesta).equals(Singleton.getInstance().getCorrectAnswers(numRespuesta))){
                            //Es correcta, sumamos un acierto
                            Singleton.getInstance().setnAciertos();
                            Log.e("QuizActivity", "Acierto ");

                        }else{
                            Singleton.getInstance().setnFallos();
                        }
                        break;
                }
                if (numRespuesta != (Singleton.getInstance().getQuestionsSize()-1)){
                    numRespuesta++;
                    textView.setText(Singleton.getInstance().getQuestion(numRespuesta));
                    rb1.setText(Singleton.getInstance().getAnswer1(numRespuesta));
                    rb2.setText(Singleton.getInstance().getAnswer2(numRespuesta));
                    rb3.setText(Singleton.getInstance().getAnswer3(numRespuesta));
                    //Incrementamos uno para printarlo y posteriormente lo decrementamos.
                    numRespuesta++;
                    tvX.setText((numRespuesta).toString());
                    numRespuesta--;

                }else{
                    //Se han terminado las preguntas, deberíamos cambiar de pantalla.
                    Intent intent = new Intent(getApplicationContext(),StatisticsActivity.class);
                    intent.putExtra("Extra1","Ok");
                    startActivity(intent);
                }


            }
        });
    }
}
