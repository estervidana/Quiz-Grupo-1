package com.example.esterwen.quizbueno;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private Button  boton;
    private ArrayList<String> preguntas;
    private ArrayList<String> correcta;
    private ArrayList<String> respuesta1;
    private ArrayList<String> respuesta2;
    private ArrayList<String> respuesta3;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        boton = (Button) findViewById(R.id.botonInicio);
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("MainActivity","Hola");
                Intent intent = new Intent(getApplicationContext(),QuizActivity.class);
                intent.putExtra("Extra1","Ok");
                startActivity(intent);
            }
        });
    }

}
